'''

@author: kidane
'''
import unittest

from nels.storage_client.config import config
from nels import storage_client

class StorageTest(unittest.TestCase):
    
    test_nels_id = 97
    def test_Register_Get_SSH_Credentials(self):
        config.API_URL =''
        config.CLIENT_KEY = ''
        config.CLIENT_SECRET =''
        credential =  storage_client.get_ssh_credential(self.test_nels_id)
        print(credential)
        assert(credential is not None)
    
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()