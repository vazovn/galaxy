import unittest

from nels.storage_client_test.storage import StorageTest


def main():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(StorageTest))

    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == "__main__":
    main()
