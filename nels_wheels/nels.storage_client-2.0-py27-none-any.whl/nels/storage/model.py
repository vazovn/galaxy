import os
from datetime import date

class file_folder(object):
    def __init__(self):
        self.name = ""
        self.path = ""
        self.description = ""
        self.last_update = date.today()
        self.is_folder = False
        self.size = 0
        