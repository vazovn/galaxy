from nels.storage.config import config
from nels.storage.model import file_folder

import requests
from requests import Request,Session

def get_return_status(response):
    return response[u'headers']['status']

def register_user(nels_id):
    try:
        response = requests.put(config.get_url("user/%s"%nels_id))
        return response.status_code == requests.codes.ok
    except:
        pass
    return False

def delete_user(nels_id):
    try:
        response = requests.delete(config.get_url("user/%s"%nels_id))
        return response.status_code == requests.codes.ok
    except:
        pass
    return False

def get_version():
    try:
        response = requests.get(config.get_url("version"))
        if(response.status_code == requests.codes.ok):
            return response.json()['version']
    except:
        pass
    return None;

def get_ssh_credential(caller_id,nels_id):
    try:
        response =  requests.get(config.get_url("user/%s/key/ssh" %nels_id))
        if(response.status_code == requests.codes.ok):
            json_response = response.json()
            return [json_response[u'hostname'],json_response[u'username'],json_response[u'key-rsa']]
    except:
        pass
    return None

def list_items(caller_id,nels_id,folder_path):
    try:
        response = Session().send(Request('INFO',config.get_url("user/%s/%s" %(nels_id,folder_path))).prepare())
        if(response.status_code == requests.codes.ok):
            return response.json()
    except:
        pass
    return None

#def add_user_to_prject(caller_id,project_id,nels_id,project_role):
#    try:
#        headers = {'project-role': project_role}
#        response = Session().send(Request('PUT',config.get_url("project/%s/user/%s" %(project_id,nels_id)),headers=headers).prepare())
#        if(response.status_code == requests.codes.ok):
#            json_response = response.json()
#            print(json_response)
#            return json_response[u'exit'] == 0
#    except:
#        pass
#    return False

#def toList(o, key):
#    if isinstance(o,dict):
#        elements = o[key]
#        if not isinstance(elements,list):
#            return [elements]
#        else:
#            return elements
#    else:
#        return []
#def list_items(caller_id,nels_id,folder_path):
#    return config.storageservice.service.listPath(config.CLIENT_KEY,caller_id, nels_id,folder_path).list
#
#def create_folder(caller_id,nels_id,parent_folder_path,name):
#    if parent_folder_path.endswith("/"):
#        path = parent_folder_path + name
#    else:
#        path = parent_folder_path + "/" + name
#    return config.storageservice.service.fsElemAdd(config.CLIENT_KEY,caller_id,nels_id,path,"folder").exitCode == 0
#
#def create_file(caller_id,nels_id,parent_folder_path,name):
#    if parent_folder_path.endswith("/"):
#        path = parent_folder_path + name
#    else:
#        path = parent_folder_path + "/" + name
#    return config.storageservice.service.fsElemAdd(config.CLIENT_KEY,caller_id,nels_id,path,"file").exitCode == 0
#
#def delete_file(caller_id,nels_id,file_path):
#    return config.storageservice.service.fsElemDelete(config.CLIENT_KEY,caller_id,nels_id,file_path).exitCode == 0
#
#def delete_folder(caller_id,nels_id,folder_path):
#    return config.storageservice.service.fsElemDelete(config.CLIENT_KEY,caller_id,nels_id,folder_path).exitCode == 0
#

