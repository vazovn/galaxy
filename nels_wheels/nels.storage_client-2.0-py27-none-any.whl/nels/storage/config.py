import ConfigParser
import os

class storage_config(object):

    def __init__(self):
        self.API_URL = "http://localhost:7601"

    def set_api_url(self,api_url):
        self.API_URL = api_url
        self.configure()
    
    def get_url(self, relative_url):
        if self.API_URL.endswith("/"):
            return self.API_URL + relative_url
        else:
            return "%s/%s" %(self.API_URL,relative_url)
    
config = storage_config()
