'''

@author: kidane
'''
import unittest

from nels.storage.config import config
from nels import storage

class StorageTest(unittest.TestCase):
    
    test_nels_id = 500
    
    def test_Version(self):
        version = storage.get_version()
        print ("version: %s" %version)
        assert("1.91" in version)
    
    def test_Register_Get_SSH_Credentials(self):
#        storage.delete_user(self.test_nels_id)
#        assert(storage.register_user(self.test_nels_id) == True)
#        credentials = storage.get_ssh_credential(self.test_nels_id,self.test_nels_id) 
#        assert(credentials is not None)
#        print "printing ssh credentials" 
#        print("host : %s" %credentials[0])
#        print("username : %s" %credentials[1])
#        print("key-rsa : %s" %credentials[2])
#        assert(storage.delete_user(self.test_nels_id) == True)
#        faileCredentails = storage.get_ssh_credential(self.test_nels_id,self.test_nels_id)
#        assert(faileCredentails is None)
        pass
    
    def test_ListItems(self):
#        items = storage.list_items(1, 1, "Personal")
#        assert(items is not None)
#        print(items) 
        pass
    
    def test_AddUserToProject(self):
        #assert(storage.add_user_to_prject(79, 24, 79, 'member'))
        pass
    
#    def test_ListItems(self):
#        items = storage.list_items(19, "")
#        assert(items is not None)
#        print items
#    
#    def test_Folder(self):
#        assert(storage.create_folder(19, "Personal", "ttt"))
#        assert (storage.delete_file(19,"Personal/ttt"))
#    
#    def test_File(self):
#        assert(storage.create_folder(19, "Personal", "ttt"))
#        assert(storage.create_file(19,"Personal/ttt","aaa.txt"))
#        assert (storage.delete_file(19,"Personal/ttt/aaa.txt"))
#        assert (storage.delete_file(19,"Personal/ttt"))
#    
#    

    
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()