import ConfigParser
import os

class storage_config(object):

    def __init__(self):
        self.API_URL = ""
        self.CLIENT_KEY = ""
        self.CLIENT_SECRET =""
    
   
    
config = storage_config()
