from nels.storage_client.config import config

import requests
from requests.auth import HTTPBasicAuth

def get_ssh_credential(nels_id):
    try:
        response =  requests.get(get_full_url("users/%s" %nels_id), auth=(config.CLIENT_KEY, config.CLIENT_SECRET))
        if(response.status_code == requests.codes.ok):
            json_response = response.json()
            return [json_response[u'hostname'],json_response[u'username'],json_response[u'key-rsa']]
    except:
        return None    
    
def get_full_url(relative_url):
    if config.API_URL.endswith("/"):
        return config.API_URL + relative_url
    else:
        return "%s/%s" %(config.API_URL,relative_url)